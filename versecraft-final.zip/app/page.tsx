export default function Page() {
  return (
    <main style={{
      background: 'linear-gradient(black, #111)',
      color: 'white',
      minHeight: '100vh',
      padding: '20px',
      fontFamily: 'Arial, sans-serif'
    }}>
      {/* Header */}
      <header style={{display:'flex', alignItems:'center', gap:'12px'}}>
        <img src="/logo.jpg" alt="VerseCraft Logo" style={{height:'50px'}} />
        <h1 style={{color:'#facc15'}}>VerseCraft</h1>
      </header>

      {/* Hero */}
      <section style={{textAlign:'center', marginTop:'40px'}}>
        <h2 style={{color:'#facc15', fontSize:'36px'}}>Words with Impact</h2>
        <p style={{maxWidth:'600px', margin:'10px auto'}}>
          Transforming ideas, messages, and emotions into custom-written poetry
          for individuals, events, and organizations.
        </p>
      </section>

      {/* Process */}
      <section style={{marginTop:'60px', textAlign:'center'}}>
        <h2 style={{color:'#facc15'}}>How It Works</h2>
        <ol style={{maxWidth:'600px', margin:'20px auto', textAlign:'left'}}>
          <li>Share your idea</li>
          <li>Define the impact</li>
          <li>Receive your draft</li>
          <li>Give feedback</li>
          <li>Final delivery</li>
        </ol>
      </section>

      {/* Contact */}
      <section style={{marginTop:'60px', textAlign:'center'}}>
        <h2 style={{color:'#facc15'}}>Contact</h2>
        <form action="https://formspree.io/f/yourID" method="POST" style={{maxWidth:'500px', margin:'0 auto'}}>
          <input name="name" placeholder="Your Name" style={{width:'100%', padding:'10px', margin:'10px 0'}} />
          <input name="email" placeholder="Your Email" style={{width:'100%', padding:'10px', margin:'10px 0'}} />
          <textarea name="message" placeholder="Your idea..." style={{width:'100%', padding:'10px', margin:'10px 0'}} />
          <button type="submit" style={{background:'#facc15', color:'black', padding:'10px 20px', border:'none'}}>
            Send Message
          </button>
        </form>
      </section>
    </main>
  );
}
